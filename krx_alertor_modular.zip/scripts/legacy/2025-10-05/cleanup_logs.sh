#!/bin/bash
find /volume2/homes/Hyungsoo/krx/krx_alertor_modular/logs -type f -mtime +14 -delete

"""거래 전략 컬렉션."""

from __future__ import annotations

__all__: list[str] = []
